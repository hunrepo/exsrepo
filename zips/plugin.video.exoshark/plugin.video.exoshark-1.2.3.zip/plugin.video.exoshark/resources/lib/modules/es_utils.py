# -*- coding: utf-8 -*-

### AdflyUrlGrabber ###
#Author:D4Vinci
#rewrited by MGF15
#algorithm from StoreClerk


def adfly_crack(code):
	import base64

	zeros = ''
	ones = ''
	for n,letter in enumerate(code):
		if n % 2 == 0:
			zeros += code[n]
		else:
			ones = code[n] + ones
	key = zeros + ones
	key = list(key)
	i = 0
	while i < len(key):
		if key[i].isdigit():
			for j in range(i+1,len(key)):
				if key[j].isdigit():
					u = int(key[i])^int(key[j])
					if u < 10:
						key[i] = str(u)
					i = j
					break
		i+=1
	key = ''.join(key).decode('base64')[16:-16]
	return key


def captcha_resolve(response, cap_cookie):
    try:
        import os
        from resources.lib.modules import client
        from resources.lib.modules import control

        i = os.path.join(control.dataPath,'img')
        f = control.openFile(i, 'w')
        f.write(client.request(response, cookie=cap_cookie))
        f.close()
        f = control.image(450,5,375,115, i)
        d = control.windowDialog
        d.addControl(f)
        control.deleteFile(i)
        d.show()
        t = ''
        k = control.keyboard('', t)
        k.doModal()
        c = k.getText() if k.isConfirmed() else None
        if c == '': c = None
        d.removeControl(f)
        d.close()
        return c
    except:
        return


def changelog_textbox():
    try:
        import os, xbmc, xbmcgui, xbmcaddon, xbmcvfs

        path = xbmcaddon.Addon().getAddonInfo('path').decode('utf-8')

        logfile = xbmcvfs.File(os.path.join(path, 'changelog.txt'))
        text = logfile.read()
        logfile.close()

        dialog = xbmcgui.Dialog()
        dialog.textviewer(xbmc.getLocalizedString(24036), text)
        return
    except:
        return


def check_subtitle(tvshowtitle, year, season, episode):
    try:
        from resources.lib.modules import client
        from resources.lib.modules import control
        import urllib, xbmcgui, json, re

        tvshowtitle = re.sub('(\(\d{4}\))', '', tvshowtitle)
        tvshowtitle = tvshowtitle.strip()
        tvshowtitle2 = re.sub('\'', '’', tvshowtitle)
        titl = urllib.quote_plus(tvshowtitle)
        titl2 = urllib.quote_plus(tvshowtitle2)
        t = '%s (%s)' % (tvshowtitle, year)
        t2 = '%s (%s)' % (tvshowtitle2, year)

        tvdb_url = 'http://thetvdb.com/api/GetSeries.php?seriesname=%s' % (titl)
        supersub_url = 'https://www.feliratok.info'
        search_url = '/index.php?term=%s&nyelv=0&action=autoname'
        ssub_url = '/index.php?search=&nyelv=Magyar&sid=%s&complexsearch=true&evad=%s&epizod1=%s&evadpakk=%s&tab=all'

        subt_url0 = supersub_url + search_url % (titl)
        r = client.request(subt_url0)
        if 'Nincs tal\u00e1lat' in r:
            if not titl == titl2:
                subt_url0 = supersub_url + search_url % (titl2)
                r = client.request(subt_url0)
                if 'Nincs tal\u00e1lat' in r:
                    control.infoDialog(u'Nincs el\u00E9rhet\u0151 magyar felirat', sound=True, icon='INFO')
                    return
            else:
                control.infoDialog(u'Nincs el\u00E9rhet\u0151 magyar felirat', sound=True, icon='INFO')
                return
        subs = re.findall('\{[^\{\}]+\}', r)
        tvshow_id = ''

        for item in subs:
            name = json.loads(item)['name']
            name2 = re.sub('(\s*\([A-Z]{2}\))', '', name)
            name2 = name2.strip()
            if name.lower() == t.lower() or name2.lower() == t.lower():
                tvshow_id = json.loads(item)['ID']
            if name.lower() == t2.lower() or name2.lower() == t2.lower():
                tvshow_id = json.loads(item)['ID']

        if tvshow_id == '':
            r = client.request(tvdb_url, timeout='10')
            r = client.parseDOM(r, 'Series')
            r = [i for i in r if 'FirstAired>%s' % year in i]
            if len(r) == 0:
                control.infoDialog(u'Nincs el\u00E9rhet\u0151 magyar felirat', sound=True, icon='INFO')
                return
            try:
                aliasname = client.parseDOM(r, 'AliasNames')[0]
            except:
                control.infoDialog(u'Nincs el\u00E9rhet\u0151 magyar felirat', sound=True, icon='INFO')
                return
            t = '%s (%s)' % (aliasname, year)
            for item in subs:
                name = json.loads(item)['name']
                name2 = re.sub('(\s*\([A-Z]{2}\))', '', name)
                name2 = name2.strip()
                if name.lower() == t.lower() or name2.lower() == t.lower():
                    tvshow_id = json.loads(item)['ID']
                if name.lower() == t2.lower() or name2.lower() == t2.lower():
                    tvshow_id = json.loads(item)['ID']

        if tvshow_id == '':
            control.infoDialog(u'Nincs el\u00E9rhet\u0151 magyar felirat', sound=True, icon='INFO')
            return

        subt_url = supersub_url + ssub_url % (tvshow_id, season, episode, '0')
        subt_r = client.request(subt_url)
        subt_o = re.findall('(?s)<div class="eredeti">[^<>]+<\/div>.+?<td align="center"[^<>]+>\s*(.+?)\s*<\/td>\s*<td align[^<>]+>\s*\d{4}-\d{2}-\d{2}', subt_r)
        subt_m = re.findall('<div class="eredeti">([^"]+)<\/div>', subt_r)
        if len(subt_m) == 0:
            subt_url = supersub_url + ssub_url % (tvshow_id, season, episode, 'on')
            subt_r = client.request(subt_url)
            subt_o = re.findall('(?s)<div class="eredeti">[^<>]+<\/div>.+?<td align="center"[^<>]+>\s*(.+?)\s*<\/td>\s*<td align[^<>]+>\s*\d{4}-\d{2}-\d{2}', subt_r)
            subt_m = re.findall('<div class="eredeti">([^"]+)<\/div>', subt_r)
            subt_m = [u'[\u00C9vadpakk] ' + i for i in subt_m]
        if len(subt_m) == 0:
            control.infoDialog(u'Nincs el\u00E9rhet\u0151 magyar felirat', sound=True, icon='INFO')
            return

        subt = ['%s - (%s)' % (i, j.replace('<b>', '').replace('<br>', ' ')) for i, j in zip(subt_m, subt_o)]
        subtext_r = '[CR]===================================================[CR][B][Magyar felirat][/B] '.join(subt)
        subtext = u'[COLOR lawngreen][B]%s SuperSubtitles felirat el\u00E9rhet\u0151:[/B][/COLOR][CR][B][Magyar felirat][/B] %s' % (len(subt), subtext_r)
        try:
            subtext = subtext.encode('utf-8')
        except:
            pass

        subtitle_dialog = xbmcgui.Dialog()
        subtitle_dialog.textviewer('Feliratok', subtext)
        return
    except:
        return