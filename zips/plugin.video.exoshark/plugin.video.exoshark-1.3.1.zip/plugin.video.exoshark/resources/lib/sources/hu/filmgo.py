# -*- coding: utf-8 -*-

import re,urllib,urlparse,json
from resources.lib.modules import es_utils
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['hu']
        self.domains = ['filmgo.cc']
        self.base_link = 'https://filmgo.cc'
        self.search_link = '/typeahead/%s'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            query = urlparse.urljoin(self.base_link, self.search_link % urllib.quote(localtitle))
            headers = {'Referer': 'https://filmgo.cc/'}
            r = client.request(query, headers=headers, XHR=True)
            if not r: raise exception()
            result = json.loads(r)

            result = [i for i in result if i['type'] == 'movie']
            result = [i for i in result if cleantitle.get(i['title'].encode('utf-8')) == cleantitle.get(localtitle)]
            if not len(result) == 1: raise Exception()

            url = result[0]['link'].encode('utf-8')
            return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url == None: return sources

            r = client.request(url)
            url1 = re.findall('a href="([^"]+)"[^<>]+>\s*<div class="link-box"', r)[0]
            r1 = client.request(url1)
            ysmm = re.findall('var ysmm = \'(.*?)\';', r1)[0]
            url2 = es_utils.adfly_crack(ysmm)
            r2 = client.request(url2)

            items = client.parseDOM(r2, 'div', attrs={'class': 'szever'})[0]
            items = client.parseDOM(items, 'div', attrs={'class': 'tr'})

            for item in items:
                try:
                    l = client.parseDOM(item, 'img', ret='src')[0]
                    l = l.rsplit('/', 1)[-1].split('.', 1)[0].strip()
                    info = 'szinkron' if l == 'hu-hu' or l == 'lt' else ''
                    q = client.parseDOM(item, 'div', attrs={'class': 'minoseg'})[0]
                    q = q.lower()
                    if q == 'hd': quality = 'HD'
                    elif 'cam' in q or 'ts' in q or q == 'mozis': quality = 'CAM'
                    else: quality = 'SD'
                    url = client.parseDOM(item, 'a', ret='href')[0]
                    url = client.replaceHTMLCodes(url)
                    url = url.encode('utf-8')
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    if valid:
                        sources.append({'source': host, 'quality': quality, 'language': 'hu', 'url': url, 'info': info, 'direct': False, 'debridonly': False})
                except:
                    pass

            return sources
        except:
            return sources


    def resolve(self, url):
            return url
